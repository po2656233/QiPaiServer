package define

const (
	NoRoom = -1
)
