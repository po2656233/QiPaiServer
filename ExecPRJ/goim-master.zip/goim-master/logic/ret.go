package main

const (
	OK          = 1
	InternalErr = 65535
)
