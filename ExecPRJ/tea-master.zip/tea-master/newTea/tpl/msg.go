package tpl

var MsgStr string = `package msg

//测试
type Hello struct {
	Name string
}
`
